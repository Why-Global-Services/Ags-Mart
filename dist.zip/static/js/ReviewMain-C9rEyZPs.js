import{r as g,j as s}from"./vendor-react-uaFMWi8n.js";import{i as re,X as se,j as oe}from"./index-DZKCIp0H.js";import{t as ie,w as D,v as ne,q as le}from"./vendor-icons-BQMEPAiX.js";import{u as F,w as ce}from"./vendor-export-CqXuPCo_.js";import{I as de,M as pe,d as ue}from"./vendor-antd-v3grzPrt.js";import"./vendor-utils-CHqvLvKm.js";import"./vendor-charts-CzYayoDx.js";let me={data:""},ge=e=>{if(typeof window=="object"){let t=(e?e.querySelector("#_goober"):window._goober)||Object.assign(document.createElement("style"),{innerHTML:" ",id:"_goober"});return t.nonce=window.__nonce__,t.parentNode||(e||document.head).appendChild(t),t.firstChild}return e||me},fe=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,xe=/\/\*[^]*?\*\/|  +/g,W=/\n+/g,_=(e,t)=>{let a="",i="",l="";for(let n in e){let o=e[n];n[0]=="@"?n[1]=="i"?a=n+" "+o+";":i+=n[1]=="f"?_(o,n):n+"{"+_(o,n[1]=="k"?"":t)+"}":typeof o=="object"?i+=_(o,t?t.replace(/([^,])+/g,c=>n.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,d=>/&/.test(d)?d.replace(/&/g,c):c?c+" "+d:d)):n):o!=null&&(n=/^--/.test(n)?n:n.replace(/[A-Z]/g,"-$&").toLowerCase(),l+=_.p?_.p(n,o):n+":"+o+";")}return a+(t&&l?t+"{"+l+"}":l)+i},N={},X=e=>{if(typeof e=="object"){let t="";for(let a in e)t+=a+X(e[a]);return t}return e},he=(e,t,a,i,l)=>{let n=X(e),o=N[n]||(N[n]=(d=>{let v=0,p=11;for(;v<d.length;)p=101*p+d.charCodeAt(v++)>>>0;return"go"+p})(n));if(!N[o]){let d=n!==e?e:(v=>{let p,j,A=[{}];for(;p=fe.exec(v.replace(xe,""));)p[4]?A.shift():p[3]?(j=p[3].replace(W," ").trim(),A.unshift(A[0][j]=A[0][j]||{})):A[0][p[1]]=p[2].replace(W," ").trim();return A[0]})(e);N[o]=_(l?{["@keyframes "+o]:d}:d,a?"":"."+o)}let c=a&&N.g?N.g:null;return a&&(N.g=N[o]),((d,v,p,j)=>{j?v.data=v.data.replace(j,d):v.data.indexOf(d)===-1&&(v.data=p?d+v.data:v.data+d)})(N[o],t,i,c),o},ve=(e,t,a)=>e.reduce((i,l,n)=>{let o=t[n];if(o&&o.call){let c=o(a),d=c&&c.props&&c.props.className||/^go/.test(c)&&c;o=d?"."+d:c&&typeof c=="object"?c.props?"":_(c,""):c===!1?"":c}return i+l+(o??"")},"");function E(e){let t=this||{},a=e.call?e(t.p):e;return he(a.unshift?a.raw?ve(a,[].slice.call(arguments,1),t.p):a.reduce((i,l)=>Object.assign(i,l&&l.call?l(t.p):l),{}):a,ge(t.target),t.g,t.o,t.k)}let Y,P,T;E.bind({g:1});let R=E.bind({k:1});function we(e,t,a,i){_.p=t,Y=e,P=a,T=i}function k(e,t){let a=this||{};return function(){let i=arguments;function l(n,o){let c=Object.assign({},n),d=c.className||l.className;a.p=Object.assign({theme:P&&P()},c),a.o=/ *go\d+/.test(d),c.className=E.apply(a,i)+(d?" "+d:"");let v=e;return e[0]&&(v=c.as||e,delete c.as),T&&v[0]&&T(c),Y(v,c)}return l}}var ye=e=>typeof e=="function",z=(e,t)=>ye(e)?e(t):e,be=(()=>{let e=0;return()=>(++e).toString()})(),je=(()=>{let e;return()=>{if(e===void 0&&typeof window<"u"){let t=matchMedia("(prefers-reduced-motion: reduce)");e=!t||t.matches}return e}})(),Ne=20,Z="default",B=(e,t)=>{let{toastLimit:a}=e.settings;switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,a)};case 1:return{...e,toasts:e.toasts.map(o=>o.id===t.toast.id?{...o,...t.toast}:o)};case 2:let{toast:i}=t;return B(e,{type:e.toasts.find(o=>o.id===i.id)?1:0,toast:i});case 3:let{toastId:l}=t;return{...e,toasts:e.toasts.map(o=>o.id===l||l===void 0?{...o,dismissed:!0,visible:!1}:o)};case 4:return t.toastId===void 0?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(o=>o.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let n=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(o=>({...o,pauseDuration:o.pauseDuration+n}))}}},Re=[],Ae={toasts:[],pausedAt:void 0,settings:{toastLimit:Ne}},S={},Q=(e,t=Z)=>{S[t]=B(S[t]||Ae,e),Re.forEach(([a,i])=>{a===t&&i(S[t])})},G=e=>Object.keys(S).forEach(t=>Q(e,t)),_e=e=>Object.keys(S).find(t=>S[t].toasts.some(a=>a.id===e)),O=(e=Z)=>t=>{Q(t,e)},ke=(e,t="blank",a)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...a,id:(a==null?void 0:a.id)||be()}),$=e=>(t,a)=>{let i=ke(t,e,a);return O(i.toasterId||_e(i.id))({type:2,toast:i}),i.id},w=(e,t)=>$("blank")(e,t);w.error=$("error");w.success=$("success");w.loading=$("loading");w.custom=$("custom");w.dismiss=(e,t)=>{let a={type:3,toastId:e};t?O(t)(a):G(a)};w.dismissAll=e=>w.dismiss(void 0,e);w.remove=(e,t)=>{let a={type:4,toastId:e};t?O(t)(a):G(a)};w.removeAll=e=>w.remove(void 0,e);w.promise=(e,t,a)=>{let i=w.loading(t.loading,{...a,...a==null?void 0:a.loading});return typeof e=="function"&&(e=e()),e.then(l=>{let n=t.success?z(t.success,l):void 0;return n?w.success(n,{id:i,...a,...a==null?void 0:a.success}):w.dismiss(i),l}).catch(l=>{let n=t.error?z(t.error,l):void 0;n?w.error(n,{id:i,...a,...a==null?void 0:a.error}):w.dismiss(i)}),e};var Se=R`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,$e=R`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,Ce=R`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,Ee=k("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${Se} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${$e} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${Ce} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,Ie=R`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,De=k("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${Ie} 1s linear infinite;
`,Fe=R`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,Pe=R`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,Te=k("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${Fe} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${Pe} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,ze=k("div")`
  position: absolute;
`,Oe=k("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,Le=R`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,Me=k("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${Le} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,He=({toast:e})=>{let{icon:t,type:a,iconTheme:i}=e;return t!==void 0?typeof t=="string"?g.createElement(Me,null,t):t:a==="blank"?null:g.createElement(Oe,null,g.createElement(De,{...i}),a!=="loading"&&g.createElement(ze,null,a==="error"?g.createElement(Ee,{...i}):g.createElement(Te,{...i})))},Ve=e=>`
0% {transform: translate3d(0,${e*-200}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,qe=e=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${e*-150}%,-1px) scale(.6); opacity:0;}
`,We="0%{opacity:0;} 100%{opacity:1;}",Xe="0%{opacity:1;} 100%{opacity:0;}",Ye=k("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,Ze=k("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,Be=(e,t)=>{let a=e.includes("top")?1:-1,[i,l]=je()?[We,Xe]:[Ve(a),qe(a)];return{animation:t?`${R(i)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${R(l)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}};g.memo(({toast:e,position:t,style:a,children:i})=>{let l=e.height?Be(e.position||t||"top-center",e.visible):{opacity:0},n=g.createElement(He,{toast:e}),o=g.createElement(Ze,{...e.ariaProps},z(e.message,e));return g.createElement(Ye,{className:e.className,style:{...l,...a,...e.style}},typeof i=="function"?i({icon:n,message:o}):g.createElement(g.Fragment,null,n,o))});we(g.createElement);E`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`;var C=w;function Qe(){var V,q;const[e,t]=g.useState([]),[a,i]=g.useState([]),[l,n]=g.useState(!0),[o,c]=g.useState(""),[d,v]=g.useState("all"),[p,j]=g.useState(null),[A,L]=g.useState(!1),[M,H]=g.useState(null);g.useEffect(()=>{J()},[]);const J=async()=>{try{n(!0);const r=await re();if(r!=null&&r.succes&&Array.isArray(r.data)){const x=r.data.map(h=>{var m,u,f,b,y;return{...h,product:h.product||{},reviews:h.reviews||[],firstImage:((m=h.product.productImages)==null?void 0:m[0])||((f=(u=h.product.nonVariant)==null?void 0:u.nonVariantImages)==null?void 0:f[0])||"https://via.placeholder.com/150",price:((y=(b=h.product.nonVariant)==null?void 0:b.price)==null?void 0:y.salePrice)||"-"}});t(x),i(x)}}catch(r){C.error("Failed to load reviews"),console.error(r)}finally{n(!1)}},K=async(r,x,h)=>{try{H(r),await oe(r),await new Promise(m=>setTimeout(m,500)),C.success("Review deleted successfully"),j(m=>{if(!m)return null;const u=m.reviews.filter(b=>b._id!==r),f=u.length>0?u.reduce((b,y)=>b+y.rating,0)/u.length:0;return{...m,reviews:u,totalReviews:u.length,averageRating:f}}),t(m=>m.map(u=>{if(u.product._id===x){const f=u.reviews.filter(y=>y._id!==r),b=f.length>0?f.reduce((y,I)=>y+I.rating,0)/f.length:0;return{...u,reviews:f,totalReviews:f.length,averageRating:b}}return u})),i(m=>m.map(u=>{if(u.product._id===x){const f=u.reviews.filter(y=>y._id!==r),b=f.length>0?f.reduce((y,I)=>y+I.rating,0)/f.length:0;return{...u,reviews:f,totalReviews:f.length,averageRating:b}}return u}))}catch(m){C.error("Failed to delete review"),console.error(m)}finally{H(null)}};g.useEffect(()=>{let r=[...e];if(o&&(r=r.filter(x=>{var h;return(h=x.product.productName)==null?void 0:h.toLowerCase().includes(o.toLowerCase())})),d!=="all"){const x=parseInt(d);r=r.filter(h=>Math.floor(h.averageRating)===x)}i(r)},[o,d,e]);const U=()=>{const r=a.flatMap((m,u)=>m.reviews.map((f,b)=>{var y;return{"S.No":u+1,"Product Name":m.product.productName||"-",Rating:f.rating,Review:f.review||"-",Customer:f.userName||"Anonymous",Date:new Date(f.createdAt).toLocaleDateString(),"Avg Rating":(y=m.averageRating)==null?void 0:y.toFixed(1),"Total Reviews":m.totalReviews}})),x=F.json_to_sheet(r),h=F.book_new();F.book_append_sheet(h,x,"Reviews"),ce(h,"Product_Reviews.xlsx"),C.success("Reviews exported successfully!")},ee=r=>{j(r),L(!0)},te=[{name:"S.No",cell:(r,x)=>x+1,width:"80px",center:!0},{name:"Image",cell:r=>s.jsx("img",{src:r.firstImage,alt:"product",className:"w-12 h-12 object-cover rounded-lg border",onError:x=>x.target.src="https://via.placeholder.com/48"}),center:!0},{name:"Product Name",selector:r=>r.product.productName||"-",sortable:!0},{name:"Category",selector:r=>r.product.productCategory||"-",center:!0},{name:"Price",cell:r=>`₹${r.price}`,center:!0},{name:"Avg Rating",cell:r=>{var x;return s.jsxs("div",{className:"flex items-center justify-center gap-1",children:[s.jsx(D,{className:"text-yellow-500"}),s.jsx("span",{className:"font-bold",children:((x=r.averageRating)==null?void 0:x.toFixed(1))||"0"}),s.jsxs("span",{className:"text-gray-500 text-sm",children:["(",r.totalReviews,")"]})]})},center:!0},{name:"Actions",cell:r=>s.jsx("button",{onClick:()=>ee(r),className:"bg-gray-100 hover:bg-gray-200 p-2 rounded-lg transition",children:s.jsx(le,{className:"text-gray-700"})}),center:!0}],ae={headCells:{style:{backgroundColor:"var(--color-table)",color:"#fff",fontWeight:"600",fontSize:"14px",textAlign:"center"}},cells:{style:{textAlign:"center",padding:"12px 8px",fontSize:"14px"}},rows:{style:{"&:hover":{backgroundColor:"#f9f9f9"}}}};return s.jsx("div",{className:"p-4 bg-gray-100 min-h-screen font-content",children:s.jsxs("div",{className:"bg-white min-h-[calc(100vh-100px)] p-6 shadow-md rounded-md",children:[s.jsxs("div",{className:"flex flex-col md:flex-row justify-between items-center mb-6 gap-4 px-8",children:[s.jsx("h1",{className:"text-2xl font-semibold text-gray-800 whitespace-nowrap",children:"Product Reviews"}),s.jsx("div",{className:"flex flex-col md:flex-row gap-4 w-full md:w-auto",children:s.jsx(de,{placeholder:"Search products...",value:o,onChange:r=>c(r.target.value),allowClear:!0,className:"w-full md:w-64"})})]}),s.jsx("div",{className:"mb-6 px-6",children:s.jsxs("div",{className:"flex items-center border-b",children:[["all","5","4","3","2","1"].map(r=>s.jsx("div",{onClick:()=>v(r),className:`cursor-pointer px-6 py-3 font-medium text-sm transition-all ${d===r?"text-secondary border-b-2 border-secondary":"text-gray-600 hover:text-gray-900"}`,children:r==="all"?"All Reviews":`${r} Star${r!=="1"?"s":""}`},r)),s.jsx("div",{className:"ml-auto",children:s.jsx("button",{onClick:U,className:"flex items-center justify-center w-10 h-10 rounded-full bg-white border border-gray-300 hover:bg-green-100 hover:border-green-500 transition-all shadow-sm",title:"Export to Excel",children:s.jsx(ie,{className:"text-secondary hover:text-green-600"})})})]})}),s.jsx("div",{className:"w-full overflow-x-auto rounded px-6",children:s.jsx(se,{columns:te,data:a,customStyles:ae,pagination:!0,highlightOnHover:!0,progressPending:l,noDataComponent:"No reviews found"})}),s.jsx(pe,{open:A,onCancel:()=>L(!1),footer:null,width:900,title:s.jsx("h2",{className:"text-2xl font-bold",children:p==null?void 0:p.product.productName}),children:p&&s.jsxs("div",{className:"space-y-8",children:[s.jsxs("div",{className:"grid md:grid-cols-2 gap-8",children:[s.jsx("div",{children:s.jsx("img",{src:p.firstImage,alt:"product",className:"w-full h-64 object-contain rounded-xl border"})}),s.jsxs("div",{className:"space-y-4",children:[s.jsxs("div",{className:"flex items-center gap-2 text-xl",children:[s.jsx(D,{className:"text-yellow-500"}),s.jsx("span",{className:"font-bold",children:(V=p.averageRating)==null?void 0:V.toFixed(1)}),s.jsxs("span",{className:"text-gray-600",children:["(",p.totalReviews," reviews)"]})]}),s.jsxs("p",{children:[s.jsx("strong",{children:"Category:"})," ",p.product.productCategory]}),s.jsxs("p",{children:[s.jsx("strong",{children:"Price:"})," ₹",p.price]}),s.jsxs("p",{className:"text-gray-700 leading-relaxed",children:[(q=p.product.productDescription)==null?void 0:q.slice(0,300),"..."]})]})]}),s.jsxs("div",{children:[s.jsx("h3",{className:"text-xl font-bold mb-4",children:"Customer Reviews"}),s.jsx("div",{className:"space-y-6 max-h-96 overflow-y-auto",children:p.reviews.length>0?p.reviews.map((r,x)=>{var h;return s.jsxs("div",{className:"bg-gray-50 p-6 rounded-xl border relative",children:[s.jsxs("div",{className:"flex justify-between items-start mb-3",children:[s.jsxs("div",{children:[s.jsx("p",{className:"font-semibold text-lg",children:r.userName}),s.jsx("p",{className:"text-sm text-gray-500",children:new Date(r.createdAt).toLocaleDateString("en-IN",{day:"numeric",month:"long",year:"numeric"})})]}),s.jsxs("div",{className:"flex items-center gap-3",children:[s.jsx("div",{className:"flex",children:[...Array(5)].map((m,u)=>s.jsx(D,{className:u<r.rating?"text-yellow-500":"text-gray-300"},u))}),s.jsx(ue,{title:"Delete Review",description:"Are you sure you want to delete this review?",onConfirm:()=>K(r._id,p.product._id),okText:"Yes",cancelText:"No",okButtonProps:{danger:!0,loading:M===r._id},children:s.jsx("button",{disabled:M===r._id,className:"text-red-600 hover:text-red-800 transition p-2 hover:bg-red-50 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed",title:"Delete review",children:s.jsx(ne,{className:"text-lg"})})})]})]}),s.jsx("p",{className:"text-gray-800",children:r.review}),((h=r.reviewImages)==null?void 0:h.length)>0&&s.jsx("div",{className:"flex flex-wrap gap-3 mt-4",children:r.reviewImages.map((m,u)=>s.jsx("img",{src:m,alt:"review",className:"w-24 h-24 object-cover rounded-lg border cursor-pointer hover:opacity-90",onClick:()=>window.open(m,"_blank")},u))})]},r._id||x)}):s.jsx("div",{className:"text-center py-8 text-gray-500",children:"No reviews available for this product"})})]})]})})]})})}const rt=()=>s.jsx("div",{children:s.jsx(Qe,{})});export{rt as default};
