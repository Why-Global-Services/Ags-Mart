import"./vendor-react-uaFMWi8n.js";
